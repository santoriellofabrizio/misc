Set objExcel = CreateObject("Excel.Application")
WScript.Echo objExcel.OperatingSystem
objExcel.Quit
