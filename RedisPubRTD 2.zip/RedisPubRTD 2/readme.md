============================================================
                 RedisPubRTD – Excel RTD Server
============================================================

RedisPubRTD is an Excel RTD (Real-Time Data) COM server that
publishes changes from Excel into Redis, using standard Excel
RTD formulas.

It supports three commands:
 - CLOCK
 - SET key value
 - PUBLISH channel key value

The distribution includes:
 - RedisPub.dll        (COM server, x32 or x64 depending on folder)
 - RedisPub.tlb        (type library, x32 or x64)
 - install_rtd32.bat   (installer for Excel 32-bit)
 - uninstall_rtd32.bat (uninstaller for Excel 32-bit)
 - install_rtd64.bat   (installer for Excel 64-bit)
 - uninstall_rtd64.bat (uninstaller for Excel 64-bit)
 - Full C# source code

NOTE:
Excel 32-bit requires the x32 version.
Excel 64-bit requires the x64 version.
You cannot mix architectures.

------------------------------------------------------------
1. PROJECT STRUCTURE
------------------------------------------------------------

C:\Desktop\RedisPubRTD\
|
|-- x32\
|     RedisPub.dll
|     RedisPub.tlb
|     install_rtd32.bat
|     uninstall_rtd32.bat
|
|-- x64\
|     RedisPub.dll
|     RedisPub.tlb
|     install_rtd64.bat
|     uninstall_rtd64.bat
|
|-- Source\
|     RedisPub.sln
|     RedisPub\
|         RedisPub.csproj
|         RedisPubRTD.cs
|         Other .cs files
|         Properties\
|
|-- README.txt

------------------------------------------------------------
2. REQUIREMENTS
------------------------------------------------------------

 - Windows (Admin rights required)
 - Excel (32-bit or 64-bit; match correct RTD version)
 - .NET Framework 4.x
 - Redis server (local or remote)
   You can find Redis installer in "Programs" folder.

------------------------------------------------------------
3. INSTALLATION
------------------------------------------------------------

Choose the installer that matches your Excel version.

------------------------------------------------------------
A) Excel 32-bit installation:
------------------------------------------------------------

1) Go to:  C:\Desktop\RedisPubRTD\x32
2) Run:    install_rtd32.bat  (as Administrator)

The installer:
 - Creates folder:
       C:\Program Files\RedisPubRTD
 - Copies:
       RedisPub.dll
       RedisPub.tlb
 - Registers the COM server using:
       RegAsm.exe /codebase /tlb

Test in Excel:

   =RTD("RedisPubRTD.Server";"";"localhost";"6379";"CLOCK")

------------------------------------------------------------
B) Excel 64-bit installation:
------------------------------------------------------------

1) Go to:  C:\Desktop\RedisPubRTD\x64
2) Run:    install_rtd64.bat  (as Administrator)

The installer:
 - Creates folder:
       C:\Program Files\RedisPubRTD64
 - Copies:
       RedisPub.dll
       RedisPub.tlb
 - Registers the COM server using:
       RegAsm.exe /codebase /tlb (64-bit version)

Test in Excel:

   =RTD("RedisPubRTD.Server";"";"localhost";"6379";"CLOCK")

------------------------------------------------------------
4. UNINSTALLATION
------------------------------------------------------------

Each version has a matching uninstaller.

------------------------------------------------------------
A) Excel 32-bit uninstall:
------------------------------------------------------------

1) Go to: C:\Desktop\RedisPubRTD\x32
2) Run:   uninstall_rtd32.bat  (Admin)

The uninstaller:
 - Closes Excel
 - Deregisters RedisPub.dll
 - Removes registry keys:
       HKCR\RedisPubRTD.Server
       HKCR\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}
       HKCR\WOW6432Node\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}
 - Deletes folder:
       C:\Program Files\RedisPubRTD

------------------------------------------------------------
B) Excel 64-bit uninstall:
------------------------------------------------------------

1) Go to: C:\Desktop\RedisPubRTD\x64
2) Run:   uninstall_rtd64.bat  (Admin)

The uninstaller:
 - Closes Excel
 - Deregisters RedisPub.dll (RegAsm 64-bit)
 - Removes registry keys:
       HKCR\RedisPubRTD.Server
       HKCR\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}
 - Deletes folder:
       C:\Program Files\RedisPubRTD64

------------------------------------------------------------
5. EXCEL USAGE EXAMPLES
------------------------------------------------------------

CLOCK:
   =RTD("RedisPubRTD.Server";"";"localhost";"6379";"CLOCK")

SET key value:
   =RTD("RedisPubRTD.Server";"";"localhost";"6379";"SET";"mykey";A1)

PUBLISH channel key value:
   =RTD("RedisPubRTD.Server";"";"localhost";"6379";"PUBLISH";"prices";"AAPL";B1)

------------------------------------------------------------
6. SOURCE CODE NOTES
------------------------------------------------------------

 - Written in C#
 - Implements Excel.IRtdServer
 - Uses StackExchange.Redis
 - Two build outputs:
       x86 (for Excel 32-bit)
       x64 (for Excel 64-bit)

To rebuild:

x32:
   msbuild RedisPub.sln /p:Configuration=Release /p:Platform=x86

x64:
   msbuild RedisPub.sln /p:Configuration=Release /p:Platform=x64

After build:
 - Generate TLB x32:
       RegAsm.exe RedisPub.dll /tlb
 - Generate TLB x64:
       RegAsm64.exe RedisPub.dll /tlb

------------------------------------------------------------
7. IMPORTANT NOTES
------------------------------------------------------------

 - Excel must match DLL architecture (32↔32, 64↔64).
 - Always run installers as Administrator.
 - Do not modify Program Files\RedisPubRTD or RedisPubRTD64 manually.
 - Program Files path must match COM registration.
 - PDB files are not required for deployment.

------------------------------------------------------------
8. LICENSE
------------------------------------------------------------

Internal proprietary component. Not for external distribution.

------------------------------------------------------------
9. SUPPORT
------------------------------------------------------------

Refer to the Source/ folder or contact desk CROSSMARKET.
