@echo off
setlocal enabledelayedexpansion

echo ============================================================
echo   INSTALLAZIONE RedisPub RTD (Excel 32-bit)
echo   ProgID: RedisPubRTD.Server
echo ============================================================

REM --- Chiudi Excel se aperto ---
tasklist | findstr /I "EXCEL.EXE" >nul
if %errorlevel%==0 (
    echo Chiudere Excel prima di installare.
    pause
    exit /b
)

REM --- Cartella di installazione DESTINAZIONE ---
set TARGET=C:\Program Files\RedisPubRTD

echo Creo cartella "%TARGET%" ...
if not exist "%TARGET%" mkdir "%TARGET%"

echo Copio DLL e TLB da: %~dp0
copy /Y "%~dp0RedisPub.dll" "%TARGET%"
copy /Y "%~dp0RedisPub.tlb" "%TARGET%" >nul 2>&1

REM --- RegAsm 32-bit ---
set REGASM=C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe

echo Registro RedisPubRTD (32-bit) da "%TARGET%\RedisPub.dll" ...
"%REGASM%" "%TARGET%\RedisPub.dll" /codebase /tlb

if %errorlevel% neq 0 (
    echo.
    echo ❌ ERRORE: Registrazione COM fallita!
    echo Controlla che Excel sia 32-bit e che il file esista.
    pause
    exit /b
)

echo.
echo ============================================================
echo   ✅ INSTALLAZIONE 32-BIT COMPLETATA!
echo   DLL registrata: "%TARGET%\RedisPub.dll"
echo   Formula Excel:
echo     =RTD("RedisPubRTD.Server";"";"localhost";"6379";"CLOCK")
echo ============================================================
pause
