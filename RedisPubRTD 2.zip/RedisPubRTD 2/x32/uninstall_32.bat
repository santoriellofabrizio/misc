@echo off
setlocal

echo ============================================================
echo       DISINSTALLAZIONE RedisPub RTD (Excel 32-bit)
echo       ProgID: RedisPubRTD.Server
echo ============================================================

REM --- Chiude Excel se aperto ---
echo Chiudo Excel se in esecuzione...
taskkill /F /IM EXCEL.EXE >nul 2>&1

REM --- Percorsi importanti ---
set INSTALL_DIR=C:\Program Files\RedisPubRTD
set DLL_PATH=%INSTALL_DIR%\RedisPub.dll

REM --- RegAsm 32-bit ---
set REGASM=C:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe

echo.
echo ------------------------------------------------------------
echo 1) Deregistrazione COM
echo ------------------------------------------------------------

if exist "%DLL_PATH%" (
    echo Deregistro "%DLL_PATH%" ...
    "%REGASM%" "%DLL_PATH%" /unregister >nul 2>&1
) else (
    echo Nessuna DLL trovata in "%DLL_PATH%".
)

echo.
echo ------------------------------------------------------------
echo 2) Rimuovo chiavi del registro COM
echo ------------------------------------------------------------

REM ProgID
reg delete "HKCR\RedisPubRTD.Server" /f >nul 2>&1

REM CLSID standard
reg delete "HKCR\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}" /f >nul 2>&1

REM CLSID per processi 32bit su Windows 64 (WOW6432Node)
reg delete "HKCR\WOW6432Node\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}" /f >nul 2>&1

echo.
echo ------------------------------------------------------------
echo 3) Rimuovo cartella di installazione
echo ------------------------------------------------------------

if exist "%INSTALL_DIR%" (
    echo Elimino "%INSTALL_DIR%" ...
    rmdir /S /Q "%INSTALL_DIR%"
) else (
    echo Cartella non trovata, nessuna rimozione.
)

echo.
echo ============================================================
echo   ✔ DISINSTALLAZIONE COMPLETA (32-bit)
echo   Il sistema è ora completamente pulito.
echo ============================================================
pause
