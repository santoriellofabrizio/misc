@echo off
setlocal

echo ============================================================
echo       DISINSTALLAZIONE RedisPub RTD (Excel 64-bit)
echo       ProgID: RedisPubRTD.Server
echo ============================================================

REM --- Chiudo Excel ---
echo Chiudo Excel se in esecuzione...
taskkill /F /IM EXCEL.EXE >nul 2>&1

REM --- Percorsi ---
set INSTALL_DIR=C:\Program Files\RedisPubRTD64
set DLL_PATH=%INSTALL_DIR%\RedisPub.dll

REM --- RegAsm 64-bit ---
set REGASM=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe

echo.
echo ------------------------------------------------------------
echo 1) Deregistrazione COM
echo ------------------------------------------------------------
if exist "%DLL_PATH%" (
    echo Deregistro "%DLL_PATH%" ...
    "%REGASM%" "%DLL_PATH%" /unregister >nul 2>&1
) else (
    echo Nessuna DLL trovata in "%DLL_PATH%".
)

echo.
echo ------------------------------------------------------------
echo 2) Rimuovo chiavi COM
echo ------------------------------------------------------------

reg delete "HKCR\RedisPubRTD.Server" /f >nul 2>&1
reg delete "HKCR\CLSID\{44E8C7B4-8A15-4AFC-93DD-2F32348586BF}" /f >nul 2>&1

echo.
echo ------------------------------------------------------------
echo 3) Rimuovo cartella di installazione
echo ------------------------------------------------------------
if exist "%INSTALL_DIR%" (
    echo Elimino "%INSTALL_DIR%" ...
    rmdir /S /Q "%INSTALL_DIR%"
) else (
    echo Cartella non trovata.
)

echo.
echo ============================================================
echo   ✔ DISINSTALLAZIONE COMPLETATA (64-bit)
echo ============================================================
pause
